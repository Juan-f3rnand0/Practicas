
public class Ventas {

	String producto;
	String cliente;
	String estado;
	double totalventa ;
	
	// 2. Definir el constructor de la clase 
	Ventas(String producto,String cliente, String estado,double totalventa){
		this.producto = producto;
		this.cliente = cliente;
		this.estado = estado;
		this.totalventa = totalventa;}
		
	// 3. Metodos SET
		public void setProducto(String producto) { 
			this.producto = producto;
			}
		public void setCliente(String cliente) { 
			this.cliente = cliente;
			}
		public void setEstado(String estado) { 
			this.estado = estado;
			}
		public void setTotalventa(double totalventa) { 
			this.totalventa = totalventa;
			}
		//Definir metodos GET 
		public  String getProducto() { 
			return this.producto;
			}
		public  String getCliente() { 
			return this.cliente;
			}
		public  String getEstado() { 
			return this.estado;
			}
		public  double getTotalventa() { 
			return this.totalventa;
			}
		
		// Agregar otros metodos
		public void insertarVenta() {
			System.out.println("El vehiculo fue insertado correctamente");
			}
		public void actualizarVenta() {
			System.out.println("El vehiculo fue cambiado correctamente");
			}
		public void consultarVenta() {
			System.out.println("El vehiculo fue cambiado correctamente");
			}
		public void cambiarestadoVenta() {
			System.out.println("El vehiculo fue cambiado correctamente");
			}
	
		
		@Override
		public String toString() {
			return "Producto: "+ this.producto+
					"\n Cliente: "+ this.cliente+"\n Estado: "+ this.estado+
					"\n Total venta: "+ this.totalventa;
			

			
	}
		
		
		
}